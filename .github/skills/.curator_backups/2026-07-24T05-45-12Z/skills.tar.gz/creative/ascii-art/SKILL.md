---
author: 0xbyt4, Hermes Agent
description: 'ASCII art: pyfiglet, cowsay, boxes, image-to-ascii.'
license: MIT
metadata:
  hermes:
    tags:
    - imported
name: ascii-art
tags:
- imported
title: Ascii Art
version: 4.0.0

---
# ASCII Art Skill

Multiple tools for different ASCII art needs. All tools are local CLI programs or free REST APIs — no API keys required.

## Tool 1: Text Banners (pyfiglet — local)

Render text as large ASCII art banners. 571 built-in fonts.

### Setup

```bash
pip install pyfiglet --break-system-packages -q
```

### Usage

```bash
python3 -m pyfiglet "YOUR TEXT" -f slant
python3 -m pyfiglet "TEXT" -f doom -w 80    # Set width
python3 -m pyfiglet --list_fonts             # List all 571 fonts
```

### Recommended fonts

| Style | Font | Best for |
|-------|------|----------|
| Clean & modern | `slant` | Project names, headers |
| Bold & blocky | `doom` | Titles, logos |
| Big & readable | `big` | Banners |
| Classic banner | `banner3` | Wide displays |
| Compact | `small` | Subtitles |
| Cyberpunk | `cyberlarge` | Tech themes |
| 3D effect | `3-d` | Splash screens |
| Gothic | `gothic` | Dramatic text |

### Tips

- Preview 2-3 fonts and let the user pick their favorite
- Short text (1-8 chars) works best with detailed fonts like `doom` or `block`
- Long text works better with compact fonts like `small` or `mini`

## Tool 2: Text Banners (asciified API — remote, no install)

Free REST API that converts text to ASCII art. 250+ FIGlet fonts. Returns plain text directly — no parsing needed. Use this when pyfiglet is not installed or as a quick alternative.

### Usage (via terminal curl)

```bash
# Basic text banner (default font)
curl -s "https://asciified.thelicato.io/api/v2/ascii?text=Hello+World"

# With a specific font
curl -s "https://asciified.thelicato.io/api/v2/ascii?text=Hello&font=Slant"
curl -s "https://asciified.thelicato.io/api/v2/ascii?text=Hello&font=Doom"
curl -s "https://asciified.thelicato.io/api/v2/ascii?text=Hello&font=Star+Wars"
curl -s "https://asciified.thelicato.io/api/v2/ascii?text=Hello&font=3-D"
curl -s "https://asciified.thelicato.io/api/v2/ascii?text=Hello&font=Banner3"

# List all available fonts (returns JSON array)
curl -s "https://asciified.thelicato.io/api/v2/fonts"
```

## Tool 3: Cowsay (Message Art)

Classic tool that wraps text in a speech bubble with an ASCII character.

### Available characters (50+)

`beavis.zen`, `bong`, `bunny`, `cheese`, `daemon`, `default`, `dragon`,
`dragon-and-cow`, `elephant`, `eyes`, `flaming-skull`, `ghostbusters`,
`hellokitty`, `kiss`, `kitty`, `koala`, `luke-koala`, `mech-and-cow`,
`meow`, `moofasa`, `moose`, `ren`, `sheep`, `skeleton`, `small`,
`stegosaurus`, `stimpy`, `supermilker`, `surgery`, `three-eyes`,
`turkey`, `turtle`, `tux`, `udder`, `vader`, `vader-koala`, `www`

### Eye/tongue modifiers

```bash
cowsay -b "Borg"       # =_= eyes
cowsay -d "Dead"       # x_x eyes
cowsay -g "Greedy"     # $_$ eyes
cowsay -p "Paranoid"   # @_@ eyes
cowsay -s "Stoned"     # *_* eyes
cowsay -w "Wired"      # O_O eyes
cowsay -e "OO" "Msg"   # Custom eyes
cowsay -T "U " "Msg"   # Custom tongue
```

## Tool 4: Boxes (Decorative Borders)

Draw decorative ASCII art borders/frames around any text. 70+ built-in designs.

### Combine with pyfiglet or asciified

```bash
python3 -m pyfiglet "HERMES" -f slant | boxes -d stone
# Or without pyfiglet installed:
curl -s "https://asciified.thelicato.io/api/v2/ascii?text=HERMES&font=Slant" | boxes -d stone
```

## Tool 5: TOIlet (Colored Text Art)

Like pyfiglet but with ANSI color effects and visual filters. Great for terminal eye candy.

### Filters

`crop`, `gay` (rainbow), `metal`, `flip`, `flop`, `180`, `left`, `right`, `border`

**Note**: toilet outputs ANSI escape codes for colors — works in terminals but may not render in all contexts (e.g., plain text files, some chat platforms).

## Tool 6: Image to ASCII Art

Convert images (PNG, JPEG, GIF, WEBP) to ASCII art.

### Option A: ascii-image-converter (recommended, modern)

```bash
# Install
sudo snap install ascii-image-converter
# OR: go install github.com/TheZoraiz/ascii-image-converter@latest
```

```bash
ascii-image-converter image.png                  # Basic
ascii-image-converter image.png -C               # Color output
ascii-image-converter image.png -d 60,30         # Set dimensions
ascii-image-converter image.png -b               # Braille characters
ascii-image-converter image.png -n               # Negative/inverted
ascii-image-converter https://url/image.jpg      # Direct URL
ascii-image-converter image.png --save-txt out   # Save as text
```

### Option B: jp2a (lightweight, JPEG only)

```bash
sudo apt install jp2a -y
jp2a --width=80 image.jpg
jp2a --colors image.jpg              # Colorized
```

## Tool 7: Search Pre-Made ASCII Art

Search curated ASCII art from the web. Use `terminal` with `curl`.

### Source A: ascii.co.uk (recommended for pre-made art)

Large collection of classic ASCII art organized by subject. Art is inside HTML `<pre>` tags. Fetch the page with curl, then extract art with a small Python snippet.

**URL pattern:** `https://ascii.co.uk/art/{subject}`

**Step 1 — Fetch the page:**

```bash
curl -s 'https://ascii.co.uk/art/cat' -o /tmp/ascii_art.html
```

**Step 2 — Extract art from pre tags:**

```python
import re, html
with open('/tmp/ascii_art.html') as f:
    text = f.read()
arts = re.findall(r'<pre[^>]*>(.*?)</pre>', text, re.DOTALL)
for art in arts:
    clean = re.sub(r'<[^>]+>', '', art)
    clean = html.unescape(clean).strip()
    if len(clean) > 30:
        print(clean)
        print('\n---\n')
```

**Available subjects** (use as URL path):
- Animals: `cat`, `dog`, `horse`, `bird`, `fish`, `dragon`, `snake`, `rabbit`, `elephant`, `dolphin`, `butterfly`, `owl`, `wolf`, `bear`, `penguin`, `turtle`
- Objects: `car`, `ship`, `airplane`, `rocket`, `guitar`, `computer`, `coffee`, `beer`, `cake`, `house`, `castle`, `sword`, `crown`, `key`
- Nature: `tree`, `flower`, `sun`, `moon`, `star`, `mountain`, `ocean`, `rainbow`
- Characters: `skull`, `robot`, `angel`, `wizard`, `pirate`, `ninja`, `alien`
- Holidays: `christmas`, `halloween`, `valentine`

**Tips:**
- Preserve artist signatures/initials — important etiquette
- Multiple art pieces per page — pick the best one for the user
- Works reliably via curl, no JavaScript needed

### Source B: GitHub Octocat API (fun easter egg)

Returns a random GitHub Octocat with a wise quote. No auth needed.

```bash
curl -s https://api.github.com/octocat
```

## Tool 8: Fun ASCII Utilities (via curl)

These free services return ASCII art directly — great for fun extras.

### QR Codes as ASCII Art

```bash
curl -s "qrenco.de/Hello+World"
curl -s "qrenco.de/https://example.com"
```

### Weather as ASCII Art

```bash
curl -s "wttr.in/London"          # Full weather report with ASCII graphics
curl -s "wttr.in/Moon"            # Moon phase in ASCII art
curl -s "v2.wttr.in/London"       # Detailed version
```

## Tool 9: LLM-Generated Custom Art (Fallback)

When tools above don't have what's needed, generate ASCII art directly using these Unicode characters:

### Character Palette

**Box Drawing:** `╔ ╗ ╚ ╝ ║ ═ ╠ ╣ ╦ ╩ ╬ ┌ ┐ └ ┘ │ ─ ├ ┤ ┬ ┴ ┼ ╭ ╮ ╰ ╯`

**Block Elements:** `░ ▒ ▓ █ ▄ ▀ ▌ ▐ ▖ ▗ ▘ ▝ ▚ ▞`

**Geometric & Symbols:** `◆ ◇ ◈ ● ○ ◉ ■ □ ▲ △ ▼ ▽ ★ ☆ ✦ ✧ ◀ ▶ ◁ ▷ ⬡ ⬢ ⌂`

### Rules

- Max width: 60 characters per line (terminal-safe)
- Max height: 15 lines for banners, 25 for scenes
- Monospace only: output must render correctly in fixed-width fonts

## Decision Flow

1. **Text as a banner** → pyfiglet if installed, otherwise asciified API via curl
2. **Wrap a message in fun character art** → cowsay
3. **Add decorative border/frame** → boxes (can combine with pyfiglet/asciified)
4. **Art of a specific thing** (cat, rocket, dragon) → ascii.co.uk via curl + parsing
5. **Convert an image to ASCII** → ascii-image-converter or jp2a
6. **QR code** → qrenco.de via curl
7. **Weather/moon art** → wttr.in via curl
8. **Something custom/creative** → LLM generation with Unicode palette
9. **Any tool not installed** → install it, or fall back to next option

## When to Use

- When you need ASCII/text art for creative or design tasks (static or animated)
- When a project requires ASCII art output or integration
- **Triggers**: "ASCII art", "ASCII video", "text art", "terminal video", "character animation"

## ASCII Video & Animation (extended pipeline)

> The former standalone `ascii-video` skill is consolidated here. Static ASCII art (banners,
> boxes, image→ASCII) is covered above; this section covers **animated/moving** ASCII output
> (video-to-ASCII, audio-reactive visualizers, generative ASCII animations, MP4/GIF export).

**Modes:** Video-to-ASCII · Audio-reactive (music visualizer) · Generative (procedural) · Hybrid
(video+audio) · Lyrics/text overlays · TTS-narrated.

**Pipeline:** `INPUT → ANALYZE → SCENE_FN → TONEMAP → SHADE → ENCODE` (single self-contained
Python script; NumPy + Pillow + SciPy + ffmpeg; no GPU required).

**Creative standard (read before coding):** treat this as cinema, not a codec. Articulate the
mood and visual story first; first-render excellence is non-negotiable; one unifying visual
language across all scenes; dense, layered, intentional — never flat black backgrounds.

**Critical implementation notes**
- **Brightness:** use adaptive `tonemap()` (percentile-based), never `canvas * N` multipliers (they
  clip highlights). Default gamma 0.75.
- **ffmpeg pipe deadlock:** never `stderr=subprocess.PIPE` on long ffmpeg runs — buffer fills at
  64KB and deadlocks. Redirect to file.
- **Font cell height:** macOS Pillow `textbbox()` returns wrong height — use `font.getmetrics()`
  (`cell_height = ascent + descent`).
- **Font compatibility:** validate Unicode palettes at init (blank-output check).

**Reference library (under `references/`):**
| File | Contents |
|------|----------|
| `ascii-video-pipeline.md` | Full SKILL body: modes, stack, 6-stage pipeline, creative direction, build steps, perf budgets |
| `ascii-video-architecture.md` | Grid system, resolution presets, font selection, character palettes (20+), color system, `GridLayer` |
| `ascii-video-composition.md` | Pixel blend modes (20), multi-grid composition, adaptive `tonemap()`, `FeedbackBuffer` |
| `ascii-video-effects.md` | Effect building blocks: noise/fBM/domain warp, voronoi, reaction-diffusion, SDFs, particles, coordinate transforms |
| `ascii-video-shaders.md` | `ShaderChain`, shader catalog (38), audio-reactive scaling, transitions, terminal rendering |
| `ascii-video-scenes.md` | Scene protocol, `Renderer`, beat-synced cutting, parallel rendering, complete examples |
| `ascii-video-inputs.md` | Audio FFT/bands/beats, video sampling, image conversion, text/lyrics, TTS integration |
| `ascii-video-optimization.md` | Hardware detection, quality profiles, vectorized patterns, parallel rendering |
| `ascii-video-troubleshooting.md` | NumPy broadcasting, blend pitfalls, multiprocessing, brightness/ffmpeg/font diagnostics |

## Pitfalls

- **Stale cache:** Always re-read files from disk after editing; don't rely on cached context
- **Context limits:** Process in batches; write results after each batch
## Verification Checklist

- [ ] Environment and dependencies are properly configured
- [ ] Ascii Art output was generated successfully
- [ ] Output meets expected quality and style requirements
- [ ] Any errors during execution were resolved
- [ ] Final result is saved or delivered as expected

## Workflow

### Phase 1: Setup

Prepare the environment and select the appropriate ASCII art tool.

| Step | Action | Output |
| --- | --- | --- |
| 1.1 | Choose tool (pyfiglet, cowsay, boxes, jp2a, chafa, etc.) | Tool selected |
| 1.2 | Configure parameters (font, size, color, output format) | Configuration set |
| 1.3 | Verify tool availability — install if missing | Tool ready |

### Phase 2: Generate

Create the ASCII art output.

| Step | Action | Output |
| --- | --- | --- |
| 2.1 | Run the selected tool with configured parameters | Raw output |
| 2.2 | Apply any post-processing (color, alignment, border) | Formatted output |
| 2.3 | Save or display the result | Final artifact |

### Phase 3: Verify

Confirm the output meets quality requirements.

- [ ] Output generated without errors
- [ ] Output meets expected quality and style
- [ ] All dependencies verified
- [ ] Result saved to expected location

### Phase 4: Cleanup

- Remove temporary files
- Restore any modified configuration
- Document the result as needed

